#' \loadmathjax{}
#' @title Randomly Sample a Cholesky Factorized, Lower Triangular Matrix from a Lewandowski-Kurowicka-Joe Distribution
#' @description Generates a lower triangular, invertible, positive-definite matrix
#' @details Using the onion method (Ghosh & Henderson, 2003), samples a Cholesky factorized lower-triangular matrix \mjeqn{L}{} from a Lewandowski-Kurowicka-Joe (LKJ) distribution given the concentration hyperparameter \mjeqn{\eta}{}, such that: \mjdeqn{A=LL^{\top}}{} where \mjeqn{A}{} is a \mjeqn{n \times n}{} matrix and is a member of the set of all symmetric, positive-definite matrices.
#' @param nDim desired dimension of the sampled \mjeqn{n \times n}{} matrix
#' @param eta concentration hyperparameter
#' @returns a lower triangular \mjeqn{n \times n}{} matrix
#' @references Ghosh, S. and Henderson, S. G. (2003). Behavior of the norta method for correlated random vector generation as the dimension increases. ACM Transactions on Modeling and Computer Simulation, 13(3), 276-294. https://doi.org/10.1145/937332.937336
#' @export
rCorr <- function(nDim, eta=1){
  OmegaL <- matrix(data=0, nrow=nDim, ncol=nDim)
  for(n in 1:nDim){
    if(n==1){
      OmegaL[n,n] = 1
    }
    else{
      beta_hyper <- eta + (n-1)/2
      beta_cell <- rbeta(n=1, shape=beta_hyper,shape2=beta_hyper)
      scale <- sqrt(beta_cell)

      z <- rnorm(n=n-1, mean=0, sd=1)
      z <- z/sqrt(sum(z^2))
      OmegaL[n,1:(n-1)] <- scale*z
      OmegaL[n,n] <- sqrt(1-scale^2)
    }
  }
  return(OmegaL)
}
